#include <iostream>

int main()
{
    int num1,num2,num3{0};

    std::cout << "Enter the first number: ";
    std::cin >> num1;

    std::cout << "Enter the second number: ";
    std::cin >> num2;

    std::cout << "Enter the third number: ";
    std::cin >> num3;

    if (num1 < num2)      // n1<n2
    {   if (num1 < num3)   // n1 <n3
        {   if (num2 < num3)   // n2<n3
            {
                std::cout << "\n" << num1 << " " << num2 << " " << num3;
            }
            else {
            std::cout << "\n" << num1 << " " << num3 << " " << num2;
            }   
        }
        else {
            std::cout << "\n" << num3 << " " << num1 << " " << num2;
        }
    }
    else {
        if (num2 < num3)   // n2 <n3
        {   if (num1 < num3)   // n1<n3
            {
                std::cout << "\n" << num2 << " " << num1 << " " << num3;
            }
            else {
            std::cout << "\n" << num2 << " " << num3 << " " << num1;
            }   
        }
        else {
            std::cout << "\n" << num3 << " " << num2 << " " << num1;
        }

    }
    return 0;
}