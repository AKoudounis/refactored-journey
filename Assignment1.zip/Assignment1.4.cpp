#include <iostream>

void Divisors(int n);

int main(){

int Num1{0};
int digits{0};

std::cout << "Enter a number with at most 7-digits: ";
std::cin >> Num1;

label:

if (Num1 >=0 && Num1 <10) //range[0,9]
{
    int digit1 = Num1 % 10;
    int digits = digit1;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;
    
    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >=10 && Num1 <100) //range [10,99]
{
    int digit1 = Num1 / 10; // on int-> 12/10 = 1
    int digit2 = Num1 % 10; // 12 mod 10 = 2
    int digits = digit1 + digit2;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;
    
    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >=100 && Num1 <1000)   //range [100,999]
{
    int digit1 = Num1 / 100; // on int-> 120/100 = 1
    int digitx = Num1 % 100; //120 mod 100 = 20
    int digit2 = digitx / 10; // 20/10 = 2
    int digit3 = digitx % 10; // 20 mod 10 = 0
    int digits = digit1 + digit2 + digit3;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;
    
    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >=1000 && Num1 <10000)  //range [1000,9999]
{
    int digit1 = Num1 / 1000; // on int-> 1225/1000 = 1
    int digitx = Num1 % 1000; //1225 mod 1000 = 225
    int digit2 = digitx / 100; // 225/100 = 2
    int digitx1 = digitx % 100; // 225 mod 100 = 25
    int digit3 = digitx1 / 10;  // 25 / 10 = 2
    int digit4 = digitx1 % 10; // 25 mod 10 = 5
    int digits = digit1 + digit2 + digit3 + digit4;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;
    
    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >=10000 && Num1 <100000)   //range [10000,99999]
{
    int digit1 = Num1 / 10000; // on int-> 12255/1000 = 1
    int digitx = Num1 % 10000; // 12255 mod 10000 = 2255
    int digit2 = digitx / 1000; // 2255/1000 = 2
    int digitx1 = digitx % 1000; // 2255 mod 1000 = 255
    int digit3 = digitx1 / 100;  // 255 / 10 = 2
    int digitx2 = digitx1 % 100; // 255 mod 10 = 55
    int digit4 = digitx2 / 10;  // 55 / 10 = 5
    int digit5 = digitx2 % 10; // 55 mod 10 = 5
    int digits = digit1 + digit2 + digit3 + digit4 + digit5;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;
    
    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >=100000 && Num1 <1000000)  //range [100000,999999]
{
    int digit1 = Num1 / 100000;
    int digitx = Num1 % 100000;  // all mods before the last mod operation (since last mod represents a digit) need to be saved to a buffer variable named digitx,x1,x2 and so on
    int digit2 = digitx / 10000; 
    int digitx1 = digitx % 10000; 
    int digit3 = digitx1 / 1000;  
    int digitx2 = digitx1 % 1000; 
    int digit4 = digitx2 / 100;  
    int digitx3 = digitx2 % 100; 
    int digit5 = digitx3 / 10;  
    int digit6 = digitx3 % 10;
    int digits = digit1 + digit2 + digit3 + digit4 + digit5 + digit6;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;
   
    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >=1000000 && Num1 <9999999)     //range [1000000,9999999]
{
    int digit1 = Num1 / 1000000;
    int digitx = Num1 % 1000000;  // all mods before the last mod operation (since last mod represents a digit) need to be saved to a buffer variable named digitx,x1,x2 and so on
    int digit2 = digitx / 100000; 
    int digitx1 = digitx % 100000; 
    int digit3 = digitx1 / 10000;  
    int digitx2 = digitx1 % 10000; 
    int digit4 = digitx2 / 1000;  
    int digitx3 = digitx2 % 1000; 
    int digit5 = digitx3 / 100;  
    int digitx4 = digitx3 % 100;
    int digit6 = digitx4 / 10;  
    int digit7 = digitx4 % 10;
    int digits = digit1 + digit2 + digit3 + digit4 + digit5 + digit6 + digit7;
    std::cout << "Sum of the digits of " << Num1 << " is: " << digits << std::endl;

    std::cout << "The divisors of " << digits << " are as follows: \n" ; // >> max possible of 9*7 = 63
    Divisors(digits);
}

else if (Num1 >= 10000000){

std::cout << "Please enter a number with at most 7-digits: ";
std::cin >> Num1;
goto label;

}

return 0;

}


void Divisors(int n) 
{ 
    for (int i = 1; i <= n; i++) 
        if (n % i == 0) 
            std::cout << i << " "; 
} 




