#include <iostream>

int main()
{
    int Grade{0};
    std::cout << "Please input the Grade: ";
    std::cin >> Grade;
     
    if (Grade >= 90){
    std::cout << "A+";
    }

    else if  (Grade < 90 && Grade >= 85){
    std::cout << "A";
    }

    else if  (Grade < 85 && Grade >= 80){
    std::cout << "A-";
    }

    else if  (Grade < 80 && Grade >= 77){
    std::cout << "B+";
    }

    else if  (Grade < 77 && Grade >= 72){
    std::cout << "B";
    }

    else if  (Grade < 72 && Grade >= 69){
    std::cout << "B-";
    }

    else if  (Grade < 69 && Grade >= 65){
    std::cout << "C+";
    }

    else if  (Grade < 65 && Grade >= 60){
    std::cout << "C";
    }

    else if  (Grade < 60 && Grade >= 55){
    std::cout << "C-";
    }

    else if  (Grade < 55 && Grade >= 50){
    std::cout << "D+";
    }

    else if  (Grade < 50 && Grade >= 45){
    std::cout << "D";
    }
    
    else if  (Grade < 45 && Grade >= 40){
    std::cout << "D-";
    }
    
    else if (Grade < 40 && Grade >= 0){
    std::cout << "F";
    }

    return 0; 
    
}