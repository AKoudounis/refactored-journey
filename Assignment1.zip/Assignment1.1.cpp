#include <iostream>

void Print();

int main()
{    
    Print(); 
    return 0; 
}

void Print()
{
    double sum,dif,pro,div{0.0};

    double Number1{0.0};
    double Number2{0.0};

    std::cout << "*****************************************\n";
    std::cout << "Please enter the first number and hit enter: "; 
    std::cin >> Number1;

    std::cout << "\nPlease enter the second number and hit enter: ";
    std::cin >> Number2; 
    std::cout << "\n\n*****************************************\n";

    sum = Number1 + Number2;
    dif = Number1 - Number2;
    pro = Number1 * Number2;
    div = Number1 / Number2;

    std::cout << "\nThe results are as follows: \n" << std::endl;
    std::cout << "The sum is:       \t" << sum << std::endl;
    std::cout << "The difference is:\t" << dif << std::endl;

    if (Number2 == 0 || Number1 == 0){
    std::cout << "The product is:   \t" << 0 << std::endl;     //remove possible answer of -0 for negative multiples ; override
    }
    else 
    std::cout << "The product is:   \t" << pro << std::endl;
    
    if (Number2 == 0)
    {
    std::cout << "The 2nd number entered was 0. Therefore, the division cannot be calculated." << std::endl; //	If the second number is 0 then this becomes the output.
    }

    else if (Number1 == 0) 
    {
        std::cout << "The division is:   \t" << 0; //uniquely for the ability to not show ans of -0 when operations of 0 divided by negative nums = 0 ; override
    }

    else if (Number1 != 0)
    {
        std::cout << "The division is:   \t" << div ;
    }
    std::cout << "\n\n*****************************************";
}
