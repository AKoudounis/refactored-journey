#include <iostream>

int main()
{
    int celsius[20] = {1, 2, 3 , 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
    const float Fahrenheit{32};
    const float Kelvin{273.15};

    std::cout << "Celsius\t Fahrenheit\tKelvin \n"; 

    for(int i = 0; i<20; i++){
    float Fahrenheitformula = Fahrenheit + (celsius[i] * 1.8);
    float Kelvinformula = Kelvin + celsius[i];
    std::cout << celsius[i]  << "\t " << Fahrenheitformula << "\t\t" << Kelvinformula << std::endl; // Fahrenheit = celsius(1.8) + 32   // kelvin = celsius + 273.15
    
    }
    return 0;
}